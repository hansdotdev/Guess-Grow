package org.mobileapp.liningmalapad.threef.activityone;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class BmiCalcActivity extends AppCompatActivity {

    private EditText heightInput,weightInput,ageInput;
    private Button calculateButton, clearButton;
    private TextView resultTextview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmi_calc);

        heightInput = findViewById(R.id.heightInput);
        weightInput = findViewById(R.id.weightInput);
        ageInput = findViewById(R.id.ageInput);
        calculateButton = findViewById(R.id.calculateButton);
        clearButton = findViewById(R.id.clearButton);
        resultTextview = findViewById(R.id.resultTextview);

        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    calculateBMI();
            }
        });

        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                clearFields();
            }
        });
    }

    private void calculateBMI(){
        String heightText = heightInput.getText().toString();
        String weighText = weightInput.getText().toString();
        String ageText = ageInput.getText().toString();

        if (heightText.isEmpty() || weighText.isEmpty() || ageText.isEmpty()){
            Toast.makeText(this, "Please enter height, weight and age.", Toast.LENGTH_SHORT).show();
            return;
        }

        double height = Double.parseDouble(heightText)/100;
        double weight = Double.parseDouble(weighText);
        int age = Integer.parseInt(ageText);

        double bmi = weight / (height * height);

        String interpretation;
        if (bmi < 18.5) {
            interpretation = "Underweight";
        } else if (bmi < 24.9) {
            interpretation = "Normal weight";
        } else if (bmi < 29.9) {
            interpretation = "Overweight";
        } else {
            interpretation = "Obese";
        }

        resultTextview.setText("Age: " + age + "\nBMI: " + String.format("%.2f", bmi) + "\nStatus: " + interpretation);
    }

    private void clearFields(){
        ageInput.setText("");
        heightInput.setText("");
        weightInput.setText("");
        resultTextview.setText("Result will display here.");
    }
}