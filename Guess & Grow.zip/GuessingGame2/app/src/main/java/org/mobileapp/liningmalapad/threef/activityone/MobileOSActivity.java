package org.mobileapp.liningmalapad.threef.activityone;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class MobileOSActivity extends AppCompatActivity {
    ImageButton sendbtn;
    EditText editComment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mobile_osactivity);

        sendbtn = findViewById(R.id.sendbtn);
        editComment = findViewById(R.id.editComment);

        sendbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAlertDialog();

            }
        });
    }
    private void showAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Thank You!");
        builder.setMessage("Your comment has been successfully submitted. Thanks!");

        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                editComment.setText("");
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }
}