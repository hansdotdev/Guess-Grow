package org.mobileapp.liningmalapad.threef.activityone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Thread myThread = new Thread(){
            @Override
            public void run() {
                try {
                    sleep(5000);
                    Intent myIntent = new Intent(MainActivity.this, MainMenu.class);
                    startActivity(myIntent);
                    MainActivity.this.finish();
                }catch (Exception error){
                    Toast.makeText(MainActivity.this, "Application Error: "+error, Toast.LENGTH_SHORT).show();
                }
            }
        };
        myThread.start();
    }
}