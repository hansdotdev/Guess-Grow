package org.mobileapp.liningmalapad.threef.activityone;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class GuessTheNumber extends AppCompatActivity {

    private int targetNumber;
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guess_the_number);

        targetNumber = random.nextInt(21);

        EditText guessInput = findViewById(R.id.GuessNum);
        TextView resultText = findViewById(R.id.textGuess);
        Button guessButton = findViewById(R.id.btnGuess);

        guessButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String guessString = guessInput.getText().toString().trim();

                if (guessString.isEmpty()) {
                    Toast.makeText(GuessTheNumber.this, "Please enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }

                int guess;
                try {
                    guess = Integer.parseInt(guessString);
                } catch (NumberFormatException e) {
                    Toast.makeText(GuessTheNumber.this, "Invalid input! Enter a number between 0 and 20.", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (guess < 0 || guess > 20) {
                    Toast.makeText(GuessTheNumber.this, "Please enter a number between 0 and 20", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (guess < targetNumber) {
                    resultText.setText("Too low! Try again.");
                } else if (guess > targetNumber) {
                    resultText.setText("Too high! Try again.");
                } else {
                    resultText.setText("Congratulations! You guessed it!");
                    targetNumber = random.nextInt(21);
                }
            }
        });
    }
}